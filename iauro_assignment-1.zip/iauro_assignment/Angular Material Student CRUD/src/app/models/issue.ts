export class Issue {
  id: number;
  name: string;
  address: string;
  url: string;
  created_at: string;
  updated_at: string;
}
